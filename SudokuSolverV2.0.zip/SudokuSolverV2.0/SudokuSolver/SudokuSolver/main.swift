//
//  main.swift
//  SudokuSolver
//
//  Created by Harrison Orsbourne on 19/08/19.
//  Copyright © 2019 Harrison Orsbourne. All rights reserved.
//

import Foundation


func characterPos(_ pos : Int, _ stringFrom : String) -> Character{
    
    let temp = stringFrom
    let index = temp.index(temp.startIndex, offsetBy : pos)
    return(temp[index])

}


//converts a string to an array
func stringToArray(input : String) -> Array<Array<Int>>{
    
    //creating the 2d array
    var ans = Array(repeating: Array(repeating: 0, count: 9), count: 9)
    
    var x = 0;
    var y = 0;
    
    var count = 1;
    
    
    while (y < 9){
        while(x < 9){
            let temp = String(characterPos(count, input));
            let temp2 = Int(temp)!
            ans[x][y] = temp2
            
            print (ans[x][y])

            count += 1
            x += 1
        }
        print("extra line")
        x = 0
        y += 1
    }
    return ans
}

//solver function
func solve(input : Array<Array<Int>>) -> String{
    
    
    //Temp
    let string = " "
    
    return string
}

//menu function
func menu() -> String{
    
    print("1) Enter Numbers")
    print("2) Generate Numbers")

    let playerChoice = readLine()
    
    if(playerChoice == "1"){
        //let the user enter numbers
    }
    else{
        //generate numbers
    }
    
    
    
    //Temp
    let string = " "
    
    return string
    
}

//initial gameloop
while(true){
    
    //calls the menu function
    let originalString = menu();
    //converts the originalString to an array
    let originalArray = stringToArray(input : originalString)
    
    //launch the solving function
    solve(input : originalArray)
    let temp = readLine()
    
}









